import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) { // цикл- 10 раз
            int result = i * 5;  // результат умножения текущего числа на 5
            System.out.println(i + " * 5 = " + result);  // результат на консоль в формате "i * 5 = result"
        }
    }
}
